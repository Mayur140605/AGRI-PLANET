import { useState } from 'react';
import { LogOut, Sprout, Bug, Store, MessageCircle, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { CropFertilizerModule } from './CropFertilizerModule';
import { PestManagementModule } from './PestManagementModule';
import { MarketManagementModule } from './MarketManagementModule';
import { ChatbotModule } from './ChatbotModule';

type TabType = 'chat' | 'crops' | 'pests' | 'markets';

export const Dashboard = () => {
  const { user, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState<TabType>('chat');

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Failed to sign out:', error);
    }
  };

  const tabs = [
    { id: 'chat' as TabType, label: 'AI Assistant', icon: MessageCircle, color: 'text-purple-600' },
    { id: 'crops' as TabType, label: 'Crops & Fertilizers', icon: Sprout, color: 'text-green-600' },
    { id: 'pests' as TabType, label: 'Pest Management', icon: Bug, color: 'text-red-600' },
    { id: 'markets' as TabType, label: 'Markets', icon: Store, color: 'text-blue-600' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="bg-green-600 p-2 rounded-lg">
                <Sprout className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">AgriVision</h1>
                <p className="text-xs text-gray-600">AI-Powered Farming Assistant</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-lg">
                <User className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-700">{user?.displayName || user?.email}</span>
              </div>
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Sign Out</span>
              </button>
            </div>
          </div>

          <nav className="flex gap-2 overflow-x-auto pb-2">
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-green-600 text-white shadow-md'
                      : 'bg-white text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : tab.color}`} />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'chat' && <ChatbotModule />}
        {activeTab === 'crops' && <CropFertilizerModule />}
        {activeTab === 'pests' && <PestManagementModule />}
        {activeTab === 'markets' && <MarketManagementModule />}
      </main>
    </div>
  );
};
