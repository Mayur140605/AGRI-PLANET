import { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, Loader2 } from 'lucide-react';
import { generateChatResponse } from '../lib/genai';

interface Message {
  role: 'user' | 'assistant';
  parts: string;
  timestamp: Date;
}

export const ChatbotModule = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      parts: `Hello! I'm your AI Farming Assistant. I can help you with:

🌾 Crop cultivation advice and fertilizer recommendations
🐛 Pest management and disease control
📊 Market prices and selling strategies
🌱 General farming questions

How can I assist you today?`,
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      role: 'user',
      parts: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const systemPrompt = `You are an expert agricultural advisor and farming assistant. Your role is to help farmers with:
- Crop cultivation guidance and seasonal planting advice
- Fertilizer recommendations (NPK ratios, organic vs chemical)
- Pest management and disease control
- Market information and pricing strategies
- Best practices for sustainable farming

Provide practical, actionable advice. Use simple language that farmers can understand. When discussing specific locations or crops, tailor your advice accordingly. If a farmer asks about a specific module (crops, pests, or markets), explain how they can use that feature in the app.

Always be helpful, respectful, and encouraging. Agriculture is challenging work, and farmers deserve support and guidance.`;

      const chatHistory = [
        { role: 'user', parts: systemPrompt },
        { role: 'model', parts: 'Understood. I will provide helpful agricultural advice to farmers.' },
        ...messages.map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: m.parts })),
        { role: 'user', parts: input }
      ];

      const response = await generateChatResponse(chatHistory as any);

      const assistantMessage: Message = {
        role: 'assistant',
        parts: response,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        role: 'assistant',
        parts: 'I apologize, but I encountered an error. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm flex flex-col h-[calc(100vh-12rem)]">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <MessageCircle className="w-7 h-7 text-purple-600" />
          AI Farming Assistant
        </h2>
        <p className="text-sm text-gray-600 mt-1">
          Ask me anything about farming, crops, pests, or markets
        </p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-4 ${
                message.role === 'user'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.parts}</p>
              <p className={`text-xs mt-2 ${
                message.role === 'user' ? 'text-green-100' : 'text-gray-500'
              }`}>
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-lg p-4">
              <Loader2 className="w-5 h-5 animate-spin text-gray-600" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-gray-200">
        <div className="flex gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about crops, pests, markets, or farming advice..."
            className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
            rows={2}
            disabled={loading}
          />
          <button
            onClick={sendMessage}
            disabled={!input.trim() || loading}
            className="bg-green-600 text-white px-6 rounded-lg font-medium hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  );
};
