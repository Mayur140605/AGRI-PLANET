import { useState } from 'react';
import { Sprout, MapPin, Calendar, TrendingUp } from 'lucide-react';
import { generateContent } from '../lib/genai';

export const CropFertilizerModule = () => {
  const [cropName, setCropName] = useState('');
  const [location, setLocation] = useState('');
  const [season, setSeason] = useState('');
  const [recommendations, setRecommendations] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const getRecommendations = async () => {
    if (!cropName || !location) return;

    setLoading(true);
    try {
      const prompt = `As an agricultural expert, provide detailed recommendations for growing ${cropName} in ${location} during ${season || 'current season'}.

Include:
1. Optimal planting time and conditions
2. Recommended fertilizers (NPK ratios, organic vs chemical)
3. Application rates and timing
4. Soil preparation tips
5. Expected yield and harvest time
6. Nearby fertilizer shop suggestions for ${location}
7. Compare latest vs past fertilizer recommendations

Format the response in a clear, structured way for farmers.`;

      const response = await generateContent(prompt);
      setRecommendations(response);
    } catch (error) {
      console.error('Error getting recommendations:', error);
      setRecommendations('Failed to get recommendations. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Sprout className="w-7 h-7 text-green-600" />
          Crop & Fertilizer Management
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Crop Name
              </label>
              <input
                type="text"
                value={cropName}
                onChange={(e) => setCropName(e.target.value)}
                placeholder="e.g., Wheat, Rice, Tomato"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Your Location
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., Punjab, India"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Season (Optional)
              </label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">Current Season</option>
                <option value="spring">Spring</option>
                <option value="summer">Summer</option>
                <option value="monsoon">Monsoon</option>
                <option value="autumn">Autumn</option>
                <option value="winter">Winter</option>
              </select>
            </div>

            <button
              onClick={getRecommendations}
              disabled={!cropName || !location || loading}
              className="w-full bg-green-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  Getting Recommendations...
                </>
              ) : (
                <>
                  <TrendingUp className="w-5 h-5" />
                  Get Recommendations
                </>
              )}
            </button>
          </div>

          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <h3 className="font-semibold text-green-900 mb-2">What You'll Get:</h3>
            <ul className="space-y-2 text-sm text-green-800">
              <li className="flex items-start gap-2">
                <span className="text-green-600 mt-1">•</span>
                <span>Seasonal planting guides for your crop</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 mt-1">•</span>
                <span>Location-specific cultivation advice</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 mt-1">•</span>
                <span>Fertilizer recommendations with NPK ratios</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 mt-1">•</span>
                <span>Comparison of latest vs past fertilizers</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 mt-1">•</span>
                <span>Nearby fertilizer shop suggestions</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {recommendations && (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">AI Recommendations</h3>
          <div className="prose max-w-none text-gray-700 whitespace-pre-wrap">
            {recommendations}
          </div>
        </div>
      )}
    </div>
  );
};
