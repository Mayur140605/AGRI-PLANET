import { useState } from 'react';
import { Bug, Shield, AlertTriangle, Leaf } from 'lucide-react';
import { generateContent } from '../lib/genai';

export const PestManagementModule = () => {
  const [cropName, setCropName] = useState('');
  const [season, setSeason] = useState('');
  const [pestInfo, setPestInfo] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const getPestInformation = async () => {
    if (!cropName) return;

    setLoading(true);
    try {
      const prompt = `As a pest management expert, provide comprehensive information about common pests affecting ${cropName} during ${season || 'all seasons'}.

Include:
1. Common Pests: List the most common insects, diseases, and weeds
2. Seasonal Pattern: When these pests are most active
3. Symptoms: How to identify pest infestations
4. Prevention Methods: Best practices to prevent pest problems
5. Control Methods: Organic and chemical control options
6. Recommended Fertilizers/Treatments: Specific products that help manage these pests
7. Integrated Pest Management (IPM) approach

Format the response clearly for farmers to understand and implement.`;

      const response = await generateContent(prompt);
      setPestInfo(response);
    } catch (error) {
      console.error('Error getting pest information:', error);
      setPestInfo('Failed to get pest information. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Bug className="w-7 h-7 text-red-600" />
          Pest Management
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Crop Name
              </label>
              <input
                type="text"
                value={cropName}
                onChange={(e) => setCropName(e.target.value)}
                placeholder="e.g., Wheat, Rice, Tomato"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Season (Optional)
              </label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                <option value="">All Seasons</option>
                <option value="spring">Spring</option>
                <option value="summer">Summer</option>
                <option value="monsoon">Monsoon</option>
                <option value="autumn">Autumn</option>
                <option value="winter">Winter</option>
              </select>
            </div>

            <button
              onClick={getPestInformation}
              disabled={!cropName || loading}
              className="w-full bg-red-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  Loading Pest Info...
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5" />
                  Get Pest Information
                </>
              )}
            </button>
          </div>

          <div className="space-y-4">
            <div className="bg-red-50 rounded-lg p-4 border border-red-200">
              <h3 className="font-semibold text-red-900 mb-2 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Quick Tips
              </h3>
              <ul className="space-y-2 text-sm text-red-800">
                <li className="flex items-start gap-2">
                  <span className="text-red-600 mt-1">•</span>
                  <span>Early detection is key to effective pest management</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-600 mt-1">•</span>
                  <span>Use integrated pest management (IPM) approaches</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-600 mt-1">•</span>
                  <span>Regular field monitoring helps prevent outbreaks</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-600 mt-1">•</span>
                  <span>Organic methods are safer for beneficial insects</span>
                </li>
              </ul>
            </div>

            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <h3 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
                <Leaf className="w-5 h-5" />
                Prevention is Better
              </h3>
              <p className="text-sm text-green-800">
                Maintaining healthy soil, proper crop rotation, and good field hygiene
                are the best defenses against pest problems.
              </p>
            </div>
          </div>
        </div>
      </div>

      {pestInfo && (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Pest Management Guide</h3>
          <div className="prose max-w-none text-gray-700 whitespace-pre-wrap">
            {pestInfo}
          </div>
        </div>
      )}
    </div>
  );
};
