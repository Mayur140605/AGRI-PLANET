import { useState } from 'react';
import { Store, TrendingUp, MapPin, DollarSign } from 'lucide-react';
import { generateContent } from '../lib/genai';

export const MarketManagementModule = () => {
  const [location, setLocation] = useState('');
  const [cropName, setCropName] = useState('');
  const [marketInfo, setMarketInfo] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const getMarketInformation = async () => {
    if (!location || !cropName) return;

    setLoading(true);
    try {
      const prompt = `As an agricultural market analyst, provide comprehensive market information for ${cropName} in ${location}.

Include:
1. Nearby Markets: List major agricultural markets/mandis in and around ${location}
2. Current Price Trends: Estimated current prices and recent trends for ${cropName}
3. Best Markets: Recommend the best markets to sell ${cropName} for maximum profit
4. Price Comparison: Compare prices across different markets if available
5. Market Days & Timings: When these markets operate
6. Transportation Tips: How to transport produce to maximize freshness
7. Market Contacts: General contact information for major markets
8. Seasonal Insights: How seasonal factors affect pricing

Provide practical, actionable information for farmers to make informed selling decisions.`;

      const response = await generateContent(prompt);
      setMarketInfo(response);
    } catch (error) {
      console.error('Error getting market information:', error);
      setMarketInfo('Failed to get market information. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Store className="w-7 h-7 text-blue-600" />
          Market Management
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Your Location
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., Amritsar, Punjab"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Crop/Produce to Sell
              </label>
              <input
                type="text"
                value={cropName}
                onChange={(e) => setCropName(e.target.value)}
                placeholder="e.g., Wheat, Rice, Tomatoes"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={getMarketInformation}
              disabled={!location || !cropName || loading}
              className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  Loading Market Data...
                </>
              ) : (
                <>
                  <TrendingUp className="w-5 h-5" />
                  Get Market Information
                </>
              )}
            </button>
          </div>

          <div className="space-y-4">
            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <h3 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Maximize Your Profit
              </h3>
              <ul className="space-y-2 text-sm text-blue-800">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-1">•</span>
                  <span>Compare prices across multiple markets before selling</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-1">•</span>
                  <span>Time your sales based on market demand patterns</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-1">•</span>
                  <span>Transport produce properly to avoid quality loss</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-1">•</span>
                  <span>Build relationships with commission agents</span>
                </li>
              </ul>
            </div>

            <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
              <h3 className="font-semibold text-amber-900 mb-2">Market Tips</h3>
              <p className="text-sm text-amber-800">
                Arrive early at markets for better prices. Keep your produce clean
                and well-sorted. Stay informed about government MSP rates and market
                regulations.
              </p>
            </div>
          </div>
        </div>
      </div>

      {marketInfo && (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Market Analysis</h3>
          <div className="prose max-w-none text-gray-700 whitespace-pre-wrap">
            {marketInfo}
          </div>
        </div>
      )}
    </div>
  );
};
