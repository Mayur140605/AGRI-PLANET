import { GoogleGenerativeAI } from "@google/generative-ai";

const API_KEY = "AIzaSyCNNbwy6K3E9jqyCGEyek7m2_OLYn6HYJI";
const genAI = new GoogleGenerativeAI(API_KEY);

export const generateContent = async (prompt: string): Promise<string> => {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const result = await model.generateContent(prompt);
    const response = result.response;
    return response.text();
  } catch (error) {
    console.error("Error generating content:", error);
    throw error;
  }
};

export const generateChatResponse = async (messages: { role: string; parts: string }[]): Promise<string> => {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const chat = model.startChat({
      history: messages.slice(0, -1).map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.parts }]
      }))
    });

    const lastMessage = messages[messages.length - 1];
    const result = await chat.sendMessage(lastMessage.parts);
    return result.response.text();
  } catch (error) {
    console.error("Error in chat:", error);
    throw error;
  }
};
