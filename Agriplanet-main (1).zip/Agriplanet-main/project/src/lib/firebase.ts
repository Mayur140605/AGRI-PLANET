import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDWTo1PBoR6s_HkXRr0V20cMCv7cV5x3gE",
  authDomain: "agrivision-f59c1.firebaseapp.com",
  projectId: "agrivision-f59c1",
  storageBucket: "agrivision-f59c1.firebasestorage.app",
  messagingSenderId: "382392591015",
  appId: "1:382392591015:web:8e22104ce3eb41a49f3182",
  measurementId: "G-FJNFVHZ256"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
